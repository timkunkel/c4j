#ifndef RATIONALNUMBERCOLLECTION_H
#define RATIONALNUMBERCOLLECTION_H

#include "rationalnumber.h"

struct RationalNumberWithCounter
{
    RationalNumber rn;
    int counter;
};

struct RationalNumberCollection
{
    RationalNumberWithCounter rnwc[1000];
    int length;
    RationalNumber totalSum;
    int totalCount;
};

void rncInit(RationalNumberCollection* rnc);
void rncAdd(RationalNumberCollection* rnc, RationalNumber rn);
void rncRemove(RationalNumberCollection* rnc, RationalNumber rn);
int rncContainsAt(RationalNumberCollection* rnc, RationalNumber rn);
int rncCount(RationalNumberCollection* rnc, RationalNumber rn);
int rncTotalUniqueCount(RationalNumberCollection* rnc);
int rncTotalCount(RationalNumberCollection* rnc);
RationalNumber rncSum(RationalNumberCollection* rnc);
RationalNumber rncAverage(RationalNumberCollection* rnc);


#endif // RATIONALNUMBERCOLLECTION_H
