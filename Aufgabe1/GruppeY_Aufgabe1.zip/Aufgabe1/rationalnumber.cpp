#include "rationalnumber.h"

int Euclid(int a, int b)
{
    if(b == 0)
        return a;
    else
        return Euclid(b, a%b);
}

bool rnIsValid(RationalNumber n)
{
    if(n.denumerator != 0)
        return true;

    return false;
}

RationalNumber normalize(RationalNumber n)
{
    if(!rnIsValid(n))
        return RationalNumber {1, 0};

    int gcd = Euclid(n.numerator, n.denumerator);
    return RationalNumber {n.numerator/gcd, n.denumerator/gcd};
}

bool rnEqual(RationalNumber n1, RationalNumber n2)
{
    if(!rnIsValid(n1) || !rnIsValid(n2))
        return false;

    n1 = normalize(n1);
    n2 = normalize(n2);
    if(n1.numerator == n2.numerator && n1.denumerator == n2.denumerator)
        return true;

    return false;
}

bool rnLessThan (RationalNumber n1, RationalNumber n2)
{
    if(!rnIsValid(n1) || !rnIsValid(n2))
        return false;

    if(((n1.numerator < 0)^(n1.denumerator < 0)) && !((n2.numerator < 0)^(n2.denumerator < 0)))
        return true;

    else if(n1.numerator / n1.denumerator < n2.numerator / n2.denumerator)
        return true;

    return false;
}


RationalNumber rnAdd(RationalNumber n1, RationalNumber n2)
{
    if(!rnIsValid(n1) || !rnIsValid(n2))
        return RationalNumber {1, 0};

    int newNum = n1.numerator * n2.denumerator + n2.numerator * n1.denumerator;
    int newDenum = n1.denumerator * n2.denumerator;
    return normalize(RationalNumber {newNum, newDenum});
}

RationalNumber rnSubtract(RationalNumber n1, RationalNumber n2)
{
    if(!rnIsValid(n1) || !rnIsValid(n2))
        return RationalNumber {1, 0};

    int newNum = n1.numerator * n2.denumerator - n2.numerator * n1.denumerator;
    int newDenum = n1.denumerator * n2.denumerator;
    return normalize(RationalNumber {newNum, newDenum});
}

RationalNumber rnMultiply(RationalNumber n1, RationalNumber n2)
{
    if(!rnIsValid(n1) || !rnIsValid(n2))
        return RationalNumber {1, 0};

    return normalize(RationalNumber {n1.numerator * n2.numerator, n1.denumerator * n2.denumerator});
}

RationalNumber rnDivide(RationalNumber n1, RationalNumber n2)
{
    if(!rnIsValid(n1) || !rnIsValid(n2))
        return RationalNumber {1, 0};

    return rnMultiply(n1, RationalNumber {n2.denumerator, n2.numerator});
}
