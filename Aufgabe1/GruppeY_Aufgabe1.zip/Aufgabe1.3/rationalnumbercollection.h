#ifndef RATIONALNUMBERCOLLECTION_H
#define RATIONALNUMBERCOLLECTION_H

#include "rationalnumber.h"

struct RationalNumberWithCounter
{
    RationalNumber rn;
    int counter;
};

struct RationalNumberCollection;

RationalNumberCollection* rncCreate(int arraySize);
void rncDelete(RationalNumberCollection* rnc);
void rncAdd(RationalNumberCollection* rnc, RationalNumber rn);
int rncContainsAt(RationalNumberCollection* rnc, RationalNumber rn);
int rncCount(RationalNumberCollection* rnc, RationalNumber rn);
int rncTotalUniqueCount(RationalNumberCollection* rnc);
int rncTotalCount(RationalNumberCollection* rnc);
RationalNumber rncSum(RationalNumberCollection* rnc);
RationalNumber rncAverage(RationalNumberCollection* rnc);


#endif // RATIONALNUMBERCOLLECTION_H
